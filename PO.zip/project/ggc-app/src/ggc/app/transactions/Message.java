package ggc.app.transactions;

/**
 * Messages.
 */
interface Message {

  // EMPTY

}