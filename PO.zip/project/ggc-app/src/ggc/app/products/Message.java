package ggc.app.products;

/**
 * Messages.
 */
interface Message {

  // EMPTY

}