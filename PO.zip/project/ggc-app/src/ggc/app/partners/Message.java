package ggc.app.partners;

/** Messages for partner menu interactions. */
interface Message {

  // EMPTY

}